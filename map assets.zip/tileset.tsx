<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tileset" tilewidth="24" tileheight="24" tilecount="207" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="24">
  <image source="kenney_pixel-platformer/Tiles/tile_0000.png" width="18" height="18"/>
 </tile>
 <tile id="25">
  <image source="kenney_pixel-platformer/Tiles/tile_0001.png" width="18" height="18"/>
 </tile>
 <tile id="26">
  <image source="kenney_pixel-platformer/Tiles/tile_0002.png" width="18" height="18"/>
 </tile>
 <tile id="27">
  <image source="kenney_pixel-platformer/Tiles/tile_0003.png" width="18" height="18"/>
 </tile>
 <tile id="28">
  <image source="kenney_pixel-platformer/Tiles/tile_0004.png" width="18" height="18"/>
 </tile>
 <tile id="29">
  <image source="kenney_pixel-platformer/Tiles/tile_0005.png" width="18" height="18"/>
 </tile>
 <tile id="30">
  <image source="kenney_pixel-platformer/Tiles/tile_0006.png" width="18" height="18"/>
 </tile>
 <tile id="31">
  <image source="kenney_pixel-platformer/Tiles/tile_0007.png" width="18" height="18"/>
 </tile>
 <tile id="32">
  <image source="kenney_pixel-platformer/Tiles/tile_0008.png" width="18" height="18"/>
 </tile>
 <tile id="33">
  <image source="kenney_pixel-platformer/Tiles/tile_0009.png" width="18" height="18"/>
 </tile>
 <tile id="34">
  <image source="kenney_pixel-platformer/Tiles/tile_0010.png" width="18" height="18"/>
 </tile>
 <tile id="35">
  <image source="kenney_pixel-platformer/Tiles/tile_0011.png" width="18" height="18"/>
 </tile>
 <tile id="36">
  <image source="kenney_pixel-platformer/Tiles/tile_0012.png" width="18" height="18"/>
 </tile>
 <tile id="37">
  <image source="kenney_pixel-platformer/Tiles/tile_0013.png" width="18" height="18"/>
 </tile>
 <tile id="38">
  <image source="kenney_pixel-platformer/Tiles/tile_0014.png" width="18" height="18"/>
 </tile>
 <tile id="39">
  <image source="kenney_pixel-platformer/Tiles/tile_0015.png" width="18" height="18"/>
 </tile>
 <tile id="40">
  <image source="kenney_pixel-platformer/Tiles/tile_0016.png" width="18" height="18"/>
 </tile>
 <tile id="41">
  <image source="kenney_pixel-platformer/Tiles/tile_0017.png" width="18" height="18"/>
 </tile>
 <tile id="42">
  <image source="kenney_pixel-platformer/Tiles/tile_0018.png" width="18" height="18"/>
 </tile>
 <tile id="43">
  <image source="kenney_pixel-platformer/Tiles/tile_0019.png" width="18" height="18"/>
 </tile>
 <tile id="44">
  <image source="kenney_pixel-platformer/Tiles/tile_0020.png" width="18" height="18"/>
 </tile>
 <tile id="45">
  <image source="kenney_pixel-platformer/Tiles/tile_0021.png" width="18" height="18"/>
 </tile>
 <tile id="46">
  <image source="kenney_pixel-platformer/Tiles/tile_0022.png" width="18" height="18"/>
 </tile>
 <tile id="47">
  <image source="kenney_pixel-platformer/Tiles/tile_0023.png" width="18" height="18"/>
 </tile>
 <tile id="48">
  <image source="kenney_pixel-platformer/Tiles/tile_0024.png" width="18" height="18"/>
 </tile>
 <tile id="49">
  <image source="kenney_pixel-platformer/Tiles/tile_0025.png" width="18" height="18"/>
 </tile>
 <tile id="50">
  <image source="kenney_pixel-platformer/Tiles/tile_0026.png" width="18" height="18"/>
 </tile>
 <tile id="51">
  <image source="kenney_pixel-platformer/Tiles/tile_0027.png" width="18" height="18"/>
 </tile>
 <tile id="52">
  <image source="kenney_pixel-platformer/Tiles/tile_0028.png" width="18" height="18"/>
 </tile>
 <tile id="53">
  <image source="kenney_pixel-platformer/Tiles/tile_0029.png" width="18" height="18"/>
 </tile>
 <tile id="54">
  <image source="kenney_pixel-platformer/Tiles/tile_0030.png" width="18" height="18"/>
 </tile>
 <tile id="55">
  <image source="kenney_pixel-platformer/Tiles/tile_0031.png" width="18" height="18"/>
 </tile>
 <tile id="56">
  <image source="kenney_pixel-platformer/Tiles/tile_0032.png" width="18" height="18"/>
 </tile>
 <tile id="57">
  <image source="kenney_pixel-platformer/Tiles/tile_0033.png" width="18" height="18"/>
 </tile>
 <tile id="58">
  <image source="kenney_pixel-platformer/Tiles/tile_0034.png" width="18" height="18"/>
 </tile>
 <tile id="59">
  <image source="kenney_pixel-platformer/Tiles/tile_0035.png" width="18" height="18"/>
 </tile>
 <tile id="60">
  <image source="kenney_pixel-platformer/Tiles/tile_0036.png" width="18" height="18"/>
 </tile>
 <tile id="61">
  <image source="kenney_pixel-platformer/Tiles/tile_0037.png" width="18" height="18"/>
 </tile>
 <tile id="62">
  <image source="kenney_pixel-platformer/Tiles/tile_0038.png" width="18" height="18"/>
 </tile>
 <tile id="63">
  <image source="kenney_pixel-platformer/Tiles/tile_0039.png" width="18" height="18"/>
 </tile>
 <tile id="64">
  <image source="kenney_pixel-platformer/Tiles/tile_0040.png" width="18" height="18"/>
 </tile>
 <tile id="65">
  <image source="kenney_pixel-platformer/Tiles/tile_0041.png" width="18" height="18"/>
 </tile>
 <tile id="66">
  <image source="kenney_pixel-platformer/Tiles/tile_0042.png" width="18" height="18"/>
 </tile>
 <tile id="67">
  <image source="kenney_pixel-platformer/Tiles/tile_0043.png" width="18" height="18"/>
 </tile>
 <tile id="68">
  <image source="kenney_pixel-platformer/Tiles/tile_0044.png" width="18" height="18"/>
 </tile>
 <tile id="69">
  <image source="kenney_pixel-platformer/Tiles/tile_0045.png" width="18" height="18"/>
 </tile>
 <tile id="70">
  <image source="kenney_pixel-platformer/Tiles/tile_0046.png" width="18" height="18"/>
 </tile>
 <tile id="71">
  <image source="kenney_pixel-platformer/Tiles/tile_0047.png" width="18" height="18"/>
 </tile>
 <tile id="72">
  <image source="kenney_pixel-platformer/Tiles/tile_0048.png" width="18" height="18"/>
 </tile>
 <tile id="73">
  <image source="kenney_pixel-platformer/Tiles/tile_0049.png" width="18" height="18"/>
 </tile>
 <tile id="74">
  <image source="kenney_pixel-platformer/Tiles/tile_0050.png" width="18" height="18"/>
 </tile>
 <tile id="75">
  <image source="kenney_pixel-platformer/Tiles/tile_0051.png" width="18" height="18"/>
 </tile>
 <tile id="76">
  <image source="kenney_pixel-platformer/Tiles/tile_0052.png" width="18" height="18"/>
 </tile>
 <tile id="77">
  <image source="kenney_pixel-platformer/Tiles/tile_0053.png" width="18" height="18"/>
 </tile>
 <tile id="78">
  <image source="kenney_pixel-platformer/Tiles/tile_0054.png" width="18" height="18"/>
 </tile>
 <tile id="79">
  <image source="kenney_pixel-platformer/Tiles/tile_0055.png" width="18" height="18"/>
 </tile>
 <tile id="80">
  <image source="kenney_pixel-platformer/Tiles/tile_0056.png" width="18" height="18"/>
 </tile>
 <tile id="81">
  <image source="kenney_pixel-platformer/Tiles/tile_0057.png" width="18" height="18"/>
 </tile>
 <tile id="82">
  <image source="kenney_pixel-platformer/Tiles/tile_0058.png" width="18" height="18"/>
 </tile>
 <tile id="83">
  <image source="kenney_pixel-platformer/Tiles/tile_0059.png" width="18" height="18"/>
 </tile>
 <tile id="84">
  <image source="kenney_pixel-platformer/Tiles/tile_0060.png" width="18" height="18"/>
 </tile>
 <tile id="85">
  <image source="kenney_pixel-platformer/Tiles/tile_0061.png" width="18" height="18"/>
 </tile>
 <tile id="86">
  <image source="kenney_pixel-platformer/Tiles/tile_0062.png" width="18" height="18"/>
 </tile>
 <tile id="87">
  <image source="kenney_pixel-platformer/Tiles/tile_0063.png" width="18" height="18"/>
 </tile>
 <tile id="88">
  <image source="kenney_pixel-platformer/Tiles/tile_0064.png" width="18" height="18"/>
 </tile>
 <tile id="89">
  <image source="kenney_pixel-platformer/Tiles/tile_0065.png" width="18" height="18"/>
 </tile>
 <tile id="90">
  <image source="kenney_pixel-platformer/Tiles/tile_0066.png" width="18" height="18"/>
 </tile>
 <tile id="91">
  <image source="kenney_pixel-platformer/Tiles/tile_0067.png" width="18" height="18"/>
 </tile>
 <tile id="92">
  <image source="kenney_pixel-platformer/Tiles/tile_0068.png" width="18" height="18"/>
 </tile>
 <tile id="93">
  <image source="kenney_pixel-platformer/Tiles/tile_0069.png" width="18" height="18"/>
 </tile>
 <tile id="94">
  <image source="kenney_pixel-platformer/Tiles/tile_0070.png" width="18" height="18"/>
 </tile>
 <tile id="95">
  <image source="kenney_pixel-platformer/Tiles/tile_0071.png" width="18" height="18"/>
 </tile>
 <tile id="96">
  <image source="kenney_pixel-platformer/Tiles/tile_0072.png" width="18" height="18"/>
 </tile>
 <tile id="97">
  <image source="kenney_pixel-platformer/Tiles/tile_0073.png" width="18" height="18"/>
 </tile>
 <tile id="98">
  <image source="kenney_pixel-platformer/Tiles/tile_0074.png" width="18" height="18"/>
 </tile>
 <tile id="99">
  <image source="kenney_pixel-platformer/Tiles/tile_0075.png" width="18" height="18"/>
 </tile>
 <tile id="100">
  <image source="kenney_pixel-platformer/Tiles/tile_0076.png" width="18" height="18"/>
 </tile>
 <tile id="101">
  <image source="kenney_pixel-platformer/Tiles/tile_0077.png" width="18" height="18"/>
 </tile>
 <tile id="102">
  <image source="kenney_pixel-platformer/Tiles/tile_0078.png" width="18" height="18"/>
 </tile>
 <tile id="103">
  <image source="kenney_pixel-platformer/Tiles/tile_0079.png" width="18" height="18"/>
 </tile>
 <tile id="104">
  <image source="kenney_pixel-platformer/Tiles/tile_0080.png" width="18" height="18"/>
 </tile>
 <tile id="105">
  <image source="kenney_pixel-platformer/Tiles/tile_0081.png" width="18" height="18"/>
 </tile>
 <tile id="106">
  <image source="kenney_pixel-platformer/Tiles/tile_0082.png" width="18" height="18"/>
 </tile>
 <tile id="107">
  <image source="kenney_pixel-platformer/Tiles/tile_0083.png" width="18" height="18"/>
 </tile>
 <tile id="108">
  <image source="kenney_pixel-platformer/Tiles/tile_0084.png" width="18" height="18"/>
 </tile>
 <tile id="109">
  <image source="kenney_pixel-platformer/Tiles/tile_0085.png" width="18" height="18"/>
 </tile>
 <tile id="110">
  <image source="kenney_pixel-platformer/Tiles/tile_0086.png" width="18" height="18"/>
 </tile>
 <tile id="111">
  <image source="kenney_pixel-platformer/Tiles/tile_0087.png" width="18" height="18"/>
 </tile>
 <tile id="112">
  <image source="kenney_pixel-platformer/Tiles/tile_0088.png" width="18" height="18"/>
 </tile>
 <tile id="113">
  <image source="kenney_pixel-platformer/Tiles/tile_0089.png" width="18" height="18"/>
 </tile>
 <tile id="114">
  <image source="kenney_pixel-platformer/Tiles/tile_0090.png" width="18" height="18"/>
 </tile>
 <tile id="115">
  <image source="kenney_pixel-platformer/Tiles/tile_0091.png" width="18" height="18"/>
 </tile>
 <tile id="116">
  <image source="kenney_pixel-platformer/Tiles/tile_0092.png" width="18" height="18"/>
 </tile>
 <tile id="117">
  <image source="kenney_pixel-platformer/Tiles/tile_0093.png" width="18" height="18"/>
 </tile>
 <tile id="118">
  <image source="kenney_pixel-platformer/Tiles/tile_0094.png" width="18" height="18"/>
 </tile>
 <tile id="119">
  <image source="kenney_pixel-platformer/Tiles/tile_0095.png" width="18" height="18"/>
 </tile>
 <tile id="120">
  <image source="kenney_pixel-platformer/Tiles/tile_0096.png" width="18" height="18"/>
 </tile>
 <tile id="121">
  <image source="kenney_pixel-platformer/Tiles/tile_0097.png" width="18" height="18"/>
 </tile>
 <tile id="122">
  <image source="kenney_pixel-platformer/Tiles/tile_0098.png" width="18" height="18"/>
 </tile>
 <tile id="123">
  <image source="kenney_pixel-platformer/Tiles/tile_0099.png" width="18" height="18"/>
 </tile>
 <tile id="124">
  <image source="kenney_pixel-platformer/Tiles/tile_0100.png" width="18" height="18"/>
 </tile>
 <tile id="125">
  <image source="kenney_pixel-platformer/Tiles/tile_0101.png" width="18" height="18"/>
 </tile>
 <tile id="126">
  <image source="kenney_pixel-platformer/Tiles/tile_0102.png" width="18" height="18"/>
 </tile>
 <tile id="127">
  <image source="kenney_pixel-platformer/Tiles/tile_0103.png" width="18" height="18"/>
 </tile>
 <tile id="128">
  <image source="kenney_pixel-platformer/Tiles/tile_0104.png" width="18" height="18"/>
 </tile>
 <tile id="129">
  <image source="kenney_pixel-platformer/Tiles/tile_0105.png" width="18" height="18"/>
 </tile>
 <tile id="130">
  <image source="kenney_pixel-platformer/Tiles/tile_0106.png" width="18" height="18"/>
 </tile>
 <tile id="131">
  <image source="kenney_pixel-platformer/Tiles/tile_0107.png" width="18" height="18"/>
 </tile>
 <tile id="132">
  <image source="kenney_pixel-platformer/Tiles/tile_0108.png" width="18" height="18"/>
 </tile>
 <tile id="133">
  <image source="kenney_pixel-platformer/Tiles/tile_0109.png" width="18" height="18"/>
 </tile>
 <tile id="134">
  <image source="kenney_pixel-platformer/Tiles/tile_0110.png" width="18" height="18"/>
 </tile>
 <tile id="135">
  <image source="kenney_pixel-platformer/Tiles/tile_0111.png" width="18" height="18"/>
 </tile>
 <tile id="136">
  <image source="kenney_pixel-platformer/Tiles/tile_0112.png" width="18" height="18"/>
 </tile>
 <tile id="137">
  <image source="kenney_pixel-platformer/Tiles/tile_0113.png" width="18" height="18"/>
 </tile>
 <tile id="138">
  <image source="kenney_pixel-platformer/Tiles/tile_0114.png" width="18" height="18"/>
 </tile>
 <tile id="139">
  <image source="kenney_pixel-platformer/Tiles/tile_0115.png" width="18" height="18"/>
 </tile>
 <tile id="140">
  <image source="kenney_pixel-platformer/Tiles/tile_0116.png" width="18" height="18"/>
 </tile>
 <tile id="141">
  <image source="kenney_pixel-platformer/Tiles/tile_0117.png" width="18" height="18"/>
 </tile>
 <tile id="142">
  <image source="kenney_pixel-platformer/Tiles/tile_0118.png" width="18" height="18"/>
 </tile>
 <tile id="143">
  <image source="kenney_pixel-platformer/Tiles/tile_0119.png" width="18" height="18"/>
 </tile>
 <tile id="144">
  <image source="kenney_pixel-platformer/Tiles/tile_0120.png" width="18" height="18"/>
 </tile>
 <tile id="145">
  <image source="kenney_pixel-platformer/Tiles/tile_0121.png" width="18" height="18"/>
 </tile>
 <tile id="146">
  <image source="kenney_pixel-platformer/Tiles/tile_0122.png" width="18" height="18"/>
 </tile>
 <tile id="147">
  <image source="kenney_pixel-platformer/Tiles/tile_0123.png" width="18" height="18"/>
 </tile>
 <tile id="148">
  <image source="kenney_pixel-platformer/Tiles/tile_0124.png" width="18" height="18"/>
 </tile>
 <tile id="149">
  <image source="kenney_pixel-platformer/Tiles/tile_0125.png" width="18" height="18"/>
 </tile>
 <tile id="150">
  <image source="kenney_pixel-platformer/Tiles/tile_0126.png" width="18" height="18"/>
 </tile>
 <tile id="151">
  <image source="kenney_pixel-platformer/Tiles/tile_0127.png" width="18" height="18"/>
 </tile>
 <tile id="152">
  <image source="kenney_pixel-platformer/Tiles/tile_0128.png" width="18" height="18"/>
 </tile>
 <tile id="153">
  <image source="kenney_pixel-platformer/Tiles/tile_0129.png" width="18" height="18"/>
 </tile>
 <tile id="154">
  <image source="kenney_pixel-platformer/Tiles/tile_0130.png" width="18" height="18"/>
 </tile>
 <tile id="155">
  <image source="kenney_pixel-platformer/Tiles/tile_0131.png" width="18" height="18"/>
 </tile>
 <tile id="156">
  <image source="kenney_pixel-platformer/Tiles/tile_0132.png" width="18" height="18"/>
 </tile>
 <tile id="157">
  <image source="kenney_pixel-platformer/Tiles/tile_0133.png" width="18" height="18"/>
 </tile>
 <tile id="158">
  <image source="kenney_pixel-platformer/Tiles/tile_0134.png" width="18" height="18"/>
 </tile>
 <tile id="159">
  <image source="kenney_pixel-platformer/Tiles/tile_0135.png" width="18" height="18"/>
 </tile>
 <tile id="160">
  <image source="kenney_pixel-platformer/Tiles/tile_0136.png" width="18" height="18"/>
 </tile>
 <tile id="161">
  <image source="kenney_pixel-platformer/Tiles/tile_0137.png" width="18" height="18"/>
 </tile>
 <tile id="162">
  <image source="kenney_pixel-platformer/Tiles/tile_0138.png" width="18" height="18"/>
 </tile>
 <tile id="163">
  <image source="kenney_pixel-platformer/Tiles/tile_0139.png" width="18" height="18"/>
 </tile>
 <tile id="164">
  <image source="kenney_pixel-platformer/Tiles/tile_0140.png" width="18" height="18"/>
 </tile>
 <tile id="165">
  <image source="kenney_pixel-platformer/Tiles/tile_0141.png" width="18" height="18"/>
 </tile>
 <tile id="166">
  <image source="kenney_pixel-platformer/Tiles/tile_0142.png" width="18" height="18"/>
 </tile>
 <tile id="167">
  <image source="kenney_pixel-platformer/Tiles/tile_0143.png" width="18" height="18"/>
 </tile>
 <tile id="168">
  <image source="kenney_pixel-platformer/Tiles/tile_0144.png" width="18" height="18"/>
 </tile>
 <tile id="169">
  <image source="kenney_pixel-platformer/Tiles/tile_0145.png" width="18" height="18"/>
 </tile>
 <tile id="170">
  <image source="kenney_pixel-platformer/Tiles/tile_0146.png" width="18" height="18"/>
 </tile>
 <tile id="171">
  <image source="kenney_pixel-platformer/Tiles/tile_0147.png" width="18" height="18"/>
 </tile>
 <tile id="172">
  <image source="kenney_pixel-platformer/Tiles/tile_0148.png" width="18" height="18"/>
 </tile>
 <tile id="173">
  <image source="kenney_pixel-platformer/Tiles/tile_0149.png" width="18" height="18"/>
 </tile>
 <tile id="174">
  <image source="kenney_pixel-platformer/Tiles/tile_0150.png" width="18" height="18"/>
 </tile>
 <tile id="175">
  <image source="kenney_pixel-platformer/Tiles/tile_0151.png" width="18" height="18"/>
 </tile>
 <tile id="176">
  <image source="kenney_pixel-platformer/Tiles/tile_0152.png" width="18" height="18"/>
 </tile>
 <tile id="177">
  <image source="kenney_pixel-platformer/Tiles/tile_0153.png" width="18" height="18"/>
 </tile>
 <tile id="178">
  <image source="kenney_pixel-platformer/Tiles/tile_0154.png" width="18" height="18"/>
 </tile>
 <tile id="179">
  <image source="kenney_pixel-platformer/Tiles/tile_0155.png" width="18" height="18"/>
 </tile>
 <tile id="180">
  <image source="kenney_pixel-platformer/Tiles/tile_0156.png" width="18" height="18"/>
 </tile>
 <tile id="181">
  <image source="kenney_pixel-platformer/Tiles/tile_0157.png" width="18" height="18"/>
 </tile>
 <tile id="182">
  <image source="kenney_pixel-platformer/Tiles/tile_0158.png" width="18" height="18"/>
 </tile>
 <tile id="183">
  <image source="kenney_pixel-platformer/Tiles/tile_0159.png" width="18" height="18"/>
 </tile>
 <tile id="184">
  <image source="kenney_pixel-platformer/Tiles/tile_0160.png" width="18" height="18"/>
 </tile>
 <tile id="185">
  <image source="kenney_pixel-platformer/Tiles/tile_0161.png" width="18" height="18"/>
 </tile>
 <tile id="186">
  <image source="kenney_pixel-platformer/Tiles/tile_0162.png" width="18" height="18"/>
 </tile>
 <tile id="187">
  <image source="kenney_pixel-platformer/Tiles/tile_0163.png" width="18" height="18"/>
 </tile>
 <tile id="188">
  <image source="kenney_pixel-platformer/Tiles/tile_0164.png" width="18" height="18"/>
 </tile>
 <tile id="189">
  <image source="kenney_pixel-platformer/Tiles/tile_0165.png" width="18" height="18"/>
 </tile>
 <tile id="190">
  <image source="kenney_pixel-platformer/Tiles/tile_0166.png" width="18" height="18"/>
 </tile>
 <tile id="191">
  <image source="kenney_pixel-platformer/Tiles/tile_0167.png" width="18" height="18"/>
 </tile>
 <tile id="192">
  <image source="kenney_pixel-platformer/Tiles/tile_0168.png" width="18" height="18"/>
 </tile>
 <tile id="193">
  <image source="kenney_pixel-platformer/Tiles/tile_0169.png" width="18" height="18"/>
 </tile>
 <tile id="194">
  <image source="kenney_pixel-platformer/Tiles/tile_0170.png" width="18" height="18"/>
 </tile>
 <tile id="195">
  <image source="kenney_pixel-platformer/Tiles/tile_0171.png" width="18" height="18"/>
 </tile>
 <tile id="196">
  <image source="kenney_pixel-platformer/Tiles/tile_0172.png" width="18" height="18"/>
 </tile>
 <tile id="197">
  <image source="kenney_pixel-platformer/Tiles/tile_0173.png" width="18" height="18"/>
 </tile>
 <tile id="198">
  <image source="kenney_pixel-platformer/Tiles/tile_0174.png" width="18" height="18"/>
 </tile>
 <tile id="199">
  <image source="kenney_pixel-platformer/Tiles/tile_0175.png" width="18" height="18"/>
 </tile>
 <tile id="200">
  <image source="kenney_pixel-platformer/Tiles/tile_0176.png" width="18" height="18"/>
 </tile>
 <tile id="201">
  <image source="kenney_pixel-platformer/Tiles/tile_0177.png" width="18" height="18"/>
 </tile>
 <tile id="202">
  <image source="kenney_pixel-platformer/Tiles/tile_0178.png" width="18" height="18"/>
 </tile>
 <tile id="203">
  <image source="kenney_pixel-platformer/Tiles/tile_0179.png" width="18" height="18"/>
 </tile>
 <tile id="204">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0000.png" width="24" height="24"/>
 </tile>
 <tile id="205">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0001.png" width="24" height="24"/>
 </tile>
 <tile id="206">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0002.png" width="24" height="24"/>
 </tile>
 <tile id="207">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0003.png" width="24" height="24"/>
 </tile>
 <tile id="208">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0004.png" width="24" height="24"/>
 </tile>
 <tile id="209">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0005.png" width="24" height="24"/>
 </tile>
 <tile id="210">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0006.png" width="24" height="24"/>
 </tile>
 <tile id="211">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0007.png" width="24" height="24"/>
 </tile>
 <tile id="212">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0008.png" width="24" height="24"/>
 </tile>
 <tile id="213">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0009.png" width="24" height="24"/>
 </tile>
 <tile id="214">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0010.png" width="24" height="24"/>
 </tile>
 <tile id="215">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0011.png" width="24" height="24"/>
 </tile>
 <tile id="216">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0012.png" width="24" height="24"/>
 </tile>
 <tile id="217">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0013.png" width="24" height="24"/>
 </tile>
 <tile id="218">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0014.png" width="24" height="24"/>
 </tile>
 <tile id="219">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0015.png" width="24" height="24"/>
 </tile>
 <tile id="220">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0016.png" width="24" height="24"/>
 </tile>
 <tile id="221">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0017.png" width="24" height="24"/>
 </tile>
 <tile id="222">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0018.png" width="24" height="24"/>
 </tile>
 <tile id="223">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0019.png" width="24" height="24"/>
 </tile>
 <tile id="224">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0020.png" width="24" height="24"/>
 </tile>
 <tile id="225">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0021.png" width="24" height="24"/>
 </tile>
 <tile id="226">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0022.png" width="24" height="24"/>
 </tile>
 <tile id="227">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0023.png" width="24" height="24"/>
 </tile>
 <tile id="228">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0024.png" width="24" height="24"/>
 </tile>
 <tile id="229">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0025.png" width="24" height="24"/>
 </tile>
 <tile id="230">
  <image source="kenney_pixel-platformer/Tiles/Characters/tile_0026.png" width="24" height="24"/>
 </tile>
</tileset>
